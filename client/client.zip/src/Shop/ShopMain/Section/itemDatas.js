const itemNumber = [
  {
    "_id" : 1,
    "name" : "목걸이"
  },
  {
    "_id" : 2,
    "name" : "티셔츠"
  },
  {
    "_id" : 3,
    "name" : "반지"
  },
]

export { itemNumber }