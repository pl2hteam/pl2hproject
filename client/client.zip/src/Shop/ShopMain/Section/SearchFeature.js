import React, { useState } from 'react';
import { Input } from 'antd';

const { Search } = Input;

const SearchFeature = (props) => {
  const [SearchTerms, setSearchTerms] = useState("");

  const searchHandler = (event) => {
    setSearchTerms(event.currentTarget.value);
    props.refreshFunction(event.currentTarget.value);
  }

  return (
    <div>
      <Search
        placeholder="아직 영어만됨"
        onChange={searchHandler}
        style={{ width: 200 }}
        value={SearchTerms}
      />
    </div>
  )
};

export default SearchFeature;
