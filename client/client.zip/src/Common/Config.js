//SERVER ROUTES
export const MYSQL_USER_SERVER = "/api/mysql/users";
export const MONGO_USER_SERVER = "/api/mongo/users";
