const express = require("express");
const { Product } = require("../../models/post");
const { Image } = require("../../models/image");
const router = express.Router();

router.post("/", (req, res) => {
  console.log(req.body);
  const Img = req.body.images;
  console.log(Img);

  Product.create({
    title: req.body.title,
    content: req.body.content,
    img: Img,
  });

  for(let i = 0; i < (Img.lenth-1); i++) {
    Image.create({
      src: Img[i],
    })
  }
});

module.exports = router;