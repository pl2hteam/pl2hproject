const express = require("express");
const router = express.Router();

const multer = require('multer');
const path = require('path');
const fs = require('fs');

const { Post, Image } = require('../../models');

// const upload = multer({
//   storage: multer.diskStorage({
//     destination(req, file, done) {
//       done(null, 'uploads');
//     },
//     filename(req, file, done) { // 제로초.png
//       const ext = path.extname(file.originalname); // 확장자 추출(.png)
//       const basename = path.basename(file.originalname, ext); // 제로초
//       done(null, basename + '_' + new Date().getTime() + ext); // 제로초15184712891.png
//     },
//   }),
//   limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
// });

router.post('/', async (req, res, next) => { // POST /post
  try {
    console.log(".........................");
    console.log(req.body);
    console.log(".........................");
    const IMGARR = req.body.img;

    const profile = await Post.create({
      title: req.body.title,
      content: req.body.content,
      // img: req.body.img,
      views: 1,
      UserId: req.body.seller,
    });
    console.log(profile);
    for (let i = 0; i < IMGARR.length; i++) {
      console.log(IMGARR[i]);
      await Image.create({
        src: IMGARR[i],
        PostId: profile.id,
      })
    };
    return res.status(200).json({ success: true, profile });
  } catch (err) {
    return res.json({ success: false, err });
  }
});

// router.post('/images', upload.array('img'), (req, res, next) => { // POST /post/images
//   console.log(req.files);
//   res.json(req.files.map((v) => v.filename));
// });



// /* 이미지 미리보기 */
// router.post("/", (req, res) => {
//   upload(req, res, err => {
//     if (err) return res.json({ success: true, err });
//     return res.json({
//       success: true,
//       img: res.req.file.path,
//       fileName: res.req.file.filename,
//     });
//   });
// });

module.exports = router;